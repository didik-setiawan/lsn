<!-- <h1 class="count">100000</h1> -->
<h4>Selamat datang <?= $user->nama ?></h4>