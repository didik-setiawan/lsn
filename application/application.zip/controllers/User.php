<?php
defined('BASEPATH') or exit('No direct script access allowed');
class User extends CI_Controller
{
    public function index()
    {
        $data = [
            'title' => 'User',
            'user' => get_user(),
            'view' => 'user/index'
        ];
        $this->load->view('template', $data);
    }

    public function setting(){
        $data = [
            'title' => 'User Settings',
            'user' => get_user(),
            'view' => 'user/setting'
        ];
        $this->load->view('template', $data);
    }

}
