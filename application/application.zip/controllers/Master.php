<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Master extends CI_Controller
{


    //Management Role User

    public function index()
    {
        redirect('master/role_user');
    }

    public function role_user()
    {
        $data = [
            'title' => 'Master Role User',
            'user' => get_user(),
            'view' => 'master/role_user',
            'list_menu' => $this->m->get_menu()->result()
        ];
        $this->load->view('template', $data);
    }

    private function validation_role()
    {
        $this->form_validation->set_rules('role', 'Nama Role', 'required|trim|is_unique[role_user.nama_role]', [
            'required' => 'Nama Role harap di isi',
            'is_unique' => 'Role sudah terdaftar'
        ]);
        if ($this->form_validation->run() == false) {
            $params = [
                'type' => 'validation',
                'err_role' => form_error('role')
            ];
            echo json_encode($params);
            die;
        } else {
            return true;
        }
    }

    public function add_role()
    {
        validation_ajax_request();
        $this->validation_role();

        $data = [
            'nama_role' => htmlspecialchars($this->input->post('role', true)),
            'status' => 1
        ];
        $this->db->insert('role_user', $data);
        if ($this->db->affected_rows() > 0) {
            $params = [
                'type' => 'result',
                'success' => true,
                'msg' => 'Role baru berhasil di tambahkan'
            ];
        } else {
            $params = [
                'type' => 'result',
                'success' => false,
                'msg' => 'Role baru gagal di tambahkan'
            ];
        }
        echo json_encode($params);
    }

    public function edit_role()
    {
        validation_ajax_request();
        $this->validation_role();

        $id = $_POST['id_role'];
        $role = htmlspecialchars($this->input->post('role', true));
        $this->db->set('nama_role', $role)->where('md5(sha1(id_role))', $id)->update('role_user');
        if ($this->db->affected_rows() > 0) {
            $params = [
                'type' => 'result',
                'success' => true,
                'msg' => 'Role berhasil di edit'
            ];
        } else {
            $params = [
                'type' => 'result',
                'success' => false,
                'msg' => 'Role gagal di edit'
            ];
        }
        echo json_encode($params);
    }

    public function change_status_role()
    {
        validation_ajax_request();
        $id = $_POST['id'];
        $type = $_POST['type'];
        if ($type == 1) {
            $this->db->set('status', 1)->where('md5(sha1(id_role))', $id)->update('role_user');
        } else if ($type == 2) {
            $this->db->set('status', 0)->where('md5(sha1(id_role))', $id)->update('role_user');
        }

        if ($this->db->affected_rows() > 0) {
            $params = [
                'success' => true,
                'msg' => 'Status role berhasil di ubah'
            ];
        } else {
            $params = [
                'success' => false,
                'msg' => 'Status role gagal di ubah'
            ];
        }
        echo json_encode($params);
    }

    public function delete_role()
    {
        validation_ajax_request();
        $id = $_POST['id'];
        $this->db->where('md5(sha1(id_role))', $id)->delete('role_user');
        if ($this->db->affected_rows() > 0) {
            $params = [
                'success' => true,
                'msg' => 'Role berhasil di hapus'
            ];
        } else {
            $params = [
                'success' => false,
                'msg' => 'Role gagal di hapus'
            ];
        }
        echo json_encode($params);
    }

    public function change_access_menu(){
        validation_ajax_request();

        $id_role = $this->input->post('id_role');

        if(empty($_POST['check'])){
            $this->db->delete('access_menu', ['id_role' => $id_role]);
            if($this->db->affected_rows() > 0){
                $params = [
                    'success' => true,
                    'msg' => 'Akses menu berhasil di perbarui'
                ];
            } else {
                $params = [
                    'success' => false,
                    'msg' => 'Akses menu gagal di perbarui'
                ];
            }

        } else {
            $menu = $_POST['check'];


            $a = count($menu);
            $data = array();

            for($b=0; $b<$a; $b++){
                array_push($data, array(
                    'id_role' => $id_role,
                    'id_menu' => $menu[$b]
                ));
            }
            $this->db->delete('access_menu', ['id_role' => $id_role]);
            $this->db->insert_batch('access_menu', $data);

            if($this->db->affected_rows() > 0){
                $params = [
                    'success' => true,
                    'msg' => 'Akses menu berhasil di perbarui'
                ];
            } else {
                $params = [
                    'success' => false,
                    'msg' => 'Akses menu gagal di perbarui'
                ];
            }
        }

        echo json_encode($params);
    }

    public function load_access_menu(){
        validation_ajax_request();
        $id = $_POST['id'];
        $data = $this->m->get_access_menu($id);
        $html = '';
        if(isset($data)){
            foreach($data as $d){
                $html .= '
                    <li><i class="'.$d->icon.'"></i> '.$d->nama_menu.'</li>
                ';
            }
        } else {
            $html = '<li>No Data</li>';
        }

        echo $html;
    }


    //Management Menu

    public function menu(){
        $data = [
            'title' => 'Master Menu',
            'user' => get_user(),
            'view' => 'master/menu'
        ];
        $this->load->view('template', $data);
    }

    private function validation_menu(){
        $this->form_validation->set_rules('menu', 'Nama menu', 'required|trim|is_unique[menu.nama_menu]',[
            'required' => 'Nama menu harap di isi',
            'is_unique' => 'Menu sudah terdaftar'
        ]);
        $this->form_validation->set_rules('icon', 'Icon menu', 'required|trim',[
            'required' => 'Icon menu harap di isi'
        ]);
        $this->form_validation->set_rules('url', 'Url menu', 'required|trim|is_unique[menu.url]',[
            'required' => 'Url menu harap di isi',
            'is_unique' => 'Url sudah terdaftar'
        ]);

        if($this->form_validation->run() == false){
            $params = [
                'type' => 'validation',
                'err_menu' => form_error('menu'),
                'err_icon' => form_error('icon'),
                'err_url' => form_error('url')
            ];
            echo json_encode($params);
            die;
        } else {
            return true;
        }


    }

    public function add_menu(){
        validation_ajax_request();
        $this->validation_menu();

        $data = [
            'nama_menu' => htmlspecialchars($this->input->post('menu', true)),
            'icon' => htmlspecialchars($this->input->post('icon', true)),
            'url' => htmlspecialchars($this->input->post('url', true)),
            'status' => 1
        ];
        $this->db->insert('menu', $data);
        if($this->db->affected_rows() > 0){
            $params = [
                'type' => 'result',
                'success' => true,
                'msg' => 'Menu baru berhasil di tambahkan'
            ];
        } else {
            $params = [
                'type' => 'result',
                'success' => false,
                'msg' => 'Menu baru gagal di tambahkan'
            ];
        }
        echo json_encode($params);

    }

    public function get_menu_row(){
        validation_ajax_request();
        $id = $_POST['id'];
        $data = $this->m->get_menu($id)->row();
        echo json_encode($data);
    }

    public function edit_menu(){
        validation_ajax_request();
        $this->validation_menu();
        $id = $this->input->post('id_menu');

        $data = [
            'nama_menu' => htmlspecialchars($this->input->post('menu', true)),
            'icon' => htmlspecialchars($this->input->post('icon', true)),
            'url' => htmlspecialchars($this->input->post('url', true))
        ];

        $this->db->where('md5(sha1(id_menu))', $id)->update('menu', $data);
        if($this->db->affected_rows() > 0){
            $params = [
                'type' => 'result',
                'success' => true,
                'msg' => 'Menu berhasil di edit'
            ];
        } else {
            $params = [
                'type' => 'result',
                'success' => false,
                'msg' => 'Menu gagal di edit'
            ];
        }
        echo json_encode($params);
    }

    public function delete_menu()
    {
        validation_ajax_request();
        $id = $_POST['id'];
        $this->db->where('md5(sha1(id_menu))', $id)->delete('menu');
        if ($this->db->affected_rows() > 0) {
            $params = [
                'success' => true,
                'msg' => 'Menu berhasil di hapus'
            ];
        } else {
            $params = [
                'success' => false,
                'msg' => 'Menu gagal di hapus'
            ];
        }
        echo json_encode($params);
    }

    public function change_status_menu()
    {
        validation_ajax_request();
        $id = $_POST['id'];
        $type = $_POST['type'];
        if ($type == 1) {
            $this->db->set('status', 1)->where('md5(sha1(id_menu))', $id)->update('menu');
        } else if ($type == 2) {
            $this->db->set('status', 0)->where('md5(sha1(id_menu))', $id)->update('menu');
        }

        if ($this->db->affected_rows() > 0) {
            $params = [
                'success' => true,
                'msg' => 'Status menu berhasil di ubah'
            ];
        } else {
            $params = [
                'success' => false,
                'msg' => 'Status menu gagal di ubah'
            ];
        }
        echo json_encode($params);
    }

}
